# 🛡️ Threat Advisory Repository

This repository contains open-source threat intelligence advisories authored and published by [YourName] for public awareness and defensive coordination.

Each advisory includes:
- Full write-up
- IOCs (IP, hash, domains, email vectors)
- YARA rules
- VirusTotal links
- Recommended mitigations

## 🔄 Current Advisories

| Date       | Title                                 | Link |
|------------|----------------------------------------|------|
| YYYY-MM-DD | Campaign Name                          | [Read](advisories/YYYY-MM_campaign-name/) |

## 📣 Attribution & Usage

All content is provided under MIT License. Attribution encouraged. Use for:
- Security operations
- Threat hunting
- Detection engineering
- Awareness and education
