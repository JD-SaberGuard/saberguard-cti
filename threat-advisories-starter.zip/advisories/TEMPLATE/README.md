# 🎯 Threat Advisory – [Insert Campaign Name Here]

## 📌 Summary
High-level summary of the threat, delivery vector, and observed behavior.

## 📥 Delivery Mechanism
Details on how the payload was delivered (e.g., phishing, drive-by, USB).

## 🔬 Payload Behavior
Technical analysis of what the payload does.

## 📎 IOCs

- IPs:
- Domains:
- SHA256 Hashes:
- Email Senders:

## 🧪 YARA Rules
Include any detection logic used or shared.

## 🌐 VirusTotal Graph / Collection
Link to public collection or embedded graph.

## 🛡️ Mitigation
Recommended steps for defenders.

## 🔍 Attribution (if any)

## 📚 References
- External reports, tools, or disclosures related to this threat
